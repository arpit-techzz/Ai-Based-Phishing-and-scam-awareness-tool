const tabs = document.querySelectorAll(".tab");
const scanInput = document.getElementById("scanInput");
const inputLabel = document.getElementById("inputLabel");
const inputHint = document.getElementById("inputHint");
const scanForm = document.getElementById("scanForm");
const scanButton = document.getElementById("scanButton");
const resultCard = document.getElementById("resultCard");
let scanType = "url";

tabs.forEach(tab => tab.addEventListener("click", () => {
  tabs.forEach(t => t.classList.remove("active"));
  tab.classList.add("active");
  scanType = tab.dataset.type;
  if (scanType === "url") {
    inputLabel.textContent = "Paste a suspicious URL";
    scanInput.placeholder = "https://example.com/...";
    inputHint.textContent = "Do not open the link. Paste the text only.";
  } else {
    inputLabel.textContent = "Paste an SMS, email or message";
    scanInput.placeholder = "Example: Your account is blocked. Verify now...";
    inputHint.textContent = "Remove personal information before scanning. Maximum 2,000 characters.";
  }
  resultCard.classList.add("hidden");
}));

scanForm.addEventListener("submit", async event => {
  event.preventDefault();
  const text = scanInput.value.trim();
  if (!text) return;
  scanButton.disabled = true;
  scanButton.textContent = "Analyzing…";
  try {
    const response = await fetch("/api/scan", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({type: scanType, text})
    });
    const data = await readJson(response);
    if (!response.ok || !data.ok) throw new Error(data.error || "Could not analyze input.");
    showResult(data);
    await refreshHistory();
  } catch (error) {
    alert(error.message || "An error occurred. Please try again.");
  } finally {
    scanButton.disabled = false;
    scanButton.innerHTML = "<span>⌕</span> Analyze safely";
  }
});

// Parse a JSON response, but give a friendly error if the server sent something else.
async function readJson(response) {
  try {
    return await response.json();
  } catch (error) {
    return {ok: false, error: "The server sent an unexpected response. Please try again."};
  }
}

// Pick the colour class for a verdict chip from the risk score.
function riskClass(score) {
  return score >= 65 ? "risk-high" : (score >= 35 ? "risk-medium" : "risk-low");
}

function showResult(data) {
  resultCard.classList.remove("hidden");
  document.getElementById("resultVerdict").textContent = data.verdict;
  document.getElementById("scoreValue").textContent = data.risk_score;
  document.getElementById("modelNote").textContent = data.model_note || "";
  document.getElementById("meterFill").style.width = `${data.risk_score}%`;
  const ring = document.getElementById("scoreRing");
  ring.style.borderTopColor = data.risk_score >= 65 ? "#c94b5c" : (data.risk_score >= 35 ? "#d19a35" : "#21856a");
  const list = document.getElementById("signalsList");
  list.replaceChildren();
  (data.signals || []).forEach(signal => {
    const li = document.createElement("li");
    li.textContent = signal;
    list.appendChild(li);
  });
}

async function refreshHistory() {
  const [historyResponse, statsResponse] = await Promise.all([
    fetch("/api/history"),
    fetch("/api/stats")
  ]);
  if (!historyResponse.ok) return;
  const rows = await historyResponse.json();
  const body = document.getElementById("historyBody");
  body.replaceChildren();
  if (!rows.length) {
    const tr = document.createElement("tr");
    tr.className = "empty-row";
    const td = document.createElement("td");
    td.colSpan = 5;
    td.textContent = "No scans yet. Try scanning a URL or message above.";
    tr.appendChild(td);
    body.appendChild(tr);
  }
  rows.slice(0, 8).forEach(row => {
    const tr = document.createElement("tr");
    [row.scan_type, row.input_text, row.verdict, `${row.risk_score}/100`, row.created_at].forEach((value, i) => {
      const td = document.createElement("td");
      td.textContent = value;
      if (i === 1) { td.className = "input-cell"; td.title = value; }
      if (i === 2) {
        const chip = document.createElement("span");
        chip.className = `verdict-chip ${riskClass(row.risk_score)}`;
        chip.textContent = value;
        td.textContent = "";
        td.appendChild(chip);
      }
      tr.appendChild(td);
    });
    body.appendChild(tr);
  });
  // Totals come from the server so they stay correct beyond the 100 rows fetched above.
  if (statsResponse.ok) {
    const stats = await statsResponse.json();
    document.getElementById("totalScans").textContent = stats.total;
    document.getElementById("riskyScans").textContent = stats.risky;
  }
}

document.getElementById("clearHistory").addEventListener("click", async () => {
  if (!confirm("Clear all locally stored scan history? This cannot be undone.")) return;
  try {
    const response = await fetch("/api/history/clear", {method: "POST"});
    if (response.ok) await refreshHistory();
    else alert("Could not clear the history. Please try again.");
  } catch (error) {
    alert("Could not reach the server. Please try again.");
  }
});
