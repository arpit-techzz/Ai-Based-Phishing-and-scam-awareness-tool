"""
Shared URL feature extraction for ShieldAI.

Both train_model.py (training) and app.py (prediction) import from this file,
so the features, their order, and the keyword lists can never drift apart.
If you change anything here, re-run `python train_model.py`.
"""

import re
from urllib.parse import urlparse

SHORT_LINK_SERVICES = {
    "bit.ly", "tinyurl.com", "t.co", "goo.gl", "is.gd", "cutt.ly", "rb.gy"
}

UNUSUAL_DOMAIN_ENDINGS = (
    ".xyz", ".top", ".click", ".work", ".country", ".gq", ".tk", ".ml", ".cf"
)

SECURITY_WORDS = (
    "login", "verify", "secure", "update", "bank", "account", "password", "wallet"
)

IP_PATTERN = re.compile(r"\d{1,3}(?:\.\d{1,3}){3}")


def parse_submitted_url(url_text):
    """Return (parsed_url, hostname), or None if the input is not a usable URL."""
    url_text = (url_text or "").strip()
    if not url_text:
        return None

    # Let users enter either "example.com" or "https://example.com".
    url_to_parse = url_text if "://" in url_text else "http://" + url_text

    try:
        parsed_url = urlparse(url_to_parse)
        hostname = (parsed_url.hostname or "").lower().strip(".")
    except ValueError:
        return None

    if not hostname or any(ch.isspace() for ch in hostname):
        return None

    return parsed_url, hostname


def extract_url_features(url_text):
    """
    Return (feature_list, details) for a URL, or (None, None) if it is invalid.

    `details` holds the facts app.py needs to explain the result.
    """
    parsed_result = parse_submitted_url(url_text)
    if parsed_result is None:
        return None, None

    url_text = url_text.strip()
    parsed_url, hostname = parsed_result
    url_lower = url_text.lower()
    path = parsed_url.path or ""
    domain_parts = hostname.split(".")

    has_ip_address = bool(IP_PATTERN.search(hostname))
    has_security_word = any(word in url_lower for word in SECURITY_WORDS)
    has_unusual_ending = hostname.endswith(UNUSUAL_DOMAIN_ENDINGS)
    is_short_link = hostname in SHORT_LINK_SERVICES

    features = [
        len(url_text),
        len(hostname),
        url_text.count("."),
        url_text.count("-"),
        url_text.count("@"),
        url_text.count("?"),
        url_text.count("="),
        url_text.count("%"),
        url_text.count("//"),
        int(parsed_url.scheme == "https"),
        int(has_ip_address),
        len(domain_parts),
        len(path),
        int(is_short_link),
        int(has_unusual_ending),
        int(has_security_word),
        int("@" in url_text),
        int("-" in hostname),
        int(len(hostname) > 35),
    ]

    details = {
        "scheme": parsed_url.scheme,
        "length": len(url_text),
        "has_ip_address": has_ip_address,
        "has_security_word": has_security_word,
        "has_unusual_ending": has_unusual_ending,
        "is_short_link": is_short_link,
        "has_at_sign": "@" in url_text,
    }
    return features, details
