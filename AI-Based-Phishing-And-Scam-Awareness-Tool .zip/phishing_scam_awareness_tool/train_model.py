"""
Train the two machine-learning models used by ShieldAI.

The included datasets are small examples for learning and demonstrations.
They should not be treated as a reliable measure of real-world security.
"""

import csv
from pathlib import Path

import joblib
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline

from url_features import extract_url_features


PROJECT_FOLDER = Path(__file__).resolve().parent
DATA_FOLDER = PROJECT_FOLDER / "data"
MODEL_FOLDER = PROJECT_FOLDER / "model"
MODEL_FOLDER.mkdir(exist_ok=True)


def read_message_dataset():
    """Read message text and labels from data/messages.csv."""
    dataset_file = DATA_FOLDER / "messages.csv"
    examples = []

    with open(dataset_file, encoding="utf-8", newline="") as csv_file:
        for row in csv.DictReader(csv_file):
            message = row["text"].strip()
            label = row["label"].strip()

            if message and label:
                examples.append((message, label))

    if not examples:
        raise ValueError(f"No message examples found in {dataset_file}")

    return examples


def train_message_classifier():
    """Train and save the text classifier for SMS and email messages."""
    examples = read_message_dataset()
    message_texts = [message for message, label in examples]
    message_labels = [label for message, label in examples]

    train_texts, test_texts, train_labels, test_labels = train_test_split(
        message_texts,
        message_labels,
        test_size=0.25,
        random_state=42,
        stratify=message_labels,
    )

    # TF-IDF converts text into numbers; Logistic Regression learns patterns
    # that are associated with the "scam" and "safe" labels.
    message_model = Pipeline([
        (
            "text_to_numbers",
            TfidfVectorizer(
                ngram_range=(1, 2),
                lowercase=True,
                strip_accents="unicode",
                max_features=6000,
                sublinear_tf=True,
            ),
        ),
        (
            "classifier",
            LogisticRegression(
                max_iter=1000,
                class_weight="balanced",
                random_state=42,
            ),
        ),
    ])

    message_model.fit(train_texts, train_labels)
    predictions = message_model.predict(test_texts)

    print("\nMESSAGE MODEL — example test split")
    print("Accuracy:", round(accuracy_score(test_labels, predictions), 3))
    print(classification_report(test_labels, predictions, zero_division=0))

    saved_file = MODEL_FOLDER / "message_model.joblib"
    joblib.dump(message_model, saved_file)
    print(f"Saved message model to: {saved_file}")


def feature_row(url_text):
    """Return the shared feature list for one URL (same code the app uses)."""
    features, _ = extract_url_features(url_text)
    if features is None:
        raise ValueError(f"Invalid URL in data/urls.csv: {url_text!r}")
    return features


def read_url_dataset():
    """Read URL examples and their labels from data/urls.csv."""
    dataset_file = DATA_FOLDER / "urls.csv"
    examples = []

    with open(dataset_file, encoding="utf-8", newline="") as csv_file:
        for row in csv.DictReader(csv_file):
            url = row["url"].strip()
            if url:
                examples.append((url, int(row["label"])))

    if not examples:
        raise ValueError(f"No URL examples found in {dataset_file}")

    return examples


def train_url_classifier():
    """Train and save the Random Forest model for URL features."""
    examples = read_url_dataset()

    url_texts = [url for url, label in examples]
    url_labels = np.asarray([label for url, label in examples], dtype=int)
    feature_rows = np.asarray(
        [feature_row(url) for url in url_texts],
        dtype=float,
    )

    train_features, test_features, train_labels, test_labels = train_test_split(
        feature_rows,
        url_labels,
        test_size=0.25,
        random_state=42,
        stratify=url_labels,
    )

    url_model = RandomForestClassifier(
        n_estimators=160,
        max_depth=8,
        class_weight="balanced",
        random_state=42,
    )

    url_model.fit(train_features, train_labels)
    predictions = url_model.predict(test_features)

    print("\nURL MODEL — example test split")
    print("Accuracy:", round(accuracy_score(test_labels, predictions), 3))
    print(classification_report(test_labels, predictions, zero_division=0))

    saved_file = MODEL_FOLDER / "url_model.joblib"
    joblib.dump(url_model, saved_file)
    print(f"Saved URL model to: {saved_file}")


if __name__ == "__main__":
    print("Training ShieldAI models...")
    train_message_classifier()
    train_url_classifier()
    print(
        "\nTraining finished. These small demo datasets are for learning only; "
        "their scores do not guarantee real-world accuracy."
    )
