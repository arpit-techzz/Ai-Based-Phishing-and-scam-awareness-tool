"""
ShieldAI: a beginner-friendly phishing and scam awareness web app.

The app checks URLs and messages, explains warning signs, and saves scan
results in a small local SQLite database. It is an educational project,
not a replacement for professional security software.
"""

from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
import re
import sqlite3
import threading
import warnings

import joblib
from flask import Flask, jsonify, render_template, request

from url_features import extract_url_features


# Keep project files beside this Python file so the app works from any folder.
PROJECT_FOLDER = Path(__file__).resolve().parent
MODEL_FOLDER = PROJECT_FOLDER / "model"
DATABASE_FILE = PROJECT_FOLDER / "scan_history.db"

MESSAGE_MODEL_FILE = MODEL_FOLDER / "message_model.joblib"
URL_MODEL_FILE = MODEL_FOLDER / "url_model.joblib"

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 32 * 1024  # Limit each request to 32 KB.


# These clues help explain why an item might be suspicious.
# A clue is not proof that a message or website is malicious.
COMMON_SCAM_PHRASES = [
    "verify your account",
    "urgent action",
    "account suspended",
    "click here",
    "claim your prize",
    "you have won",
    "send otp",
    "share otp",
    "password expired",
    "limited time",
    "confirm your bank",
    "kyc update",
    "gift card",
    "pay fee",
    "immediately",
    "blocked account",
    "update kyc",
    "won a prize",
]

# ---------------------------------------------------------------------------
# Database helpers
# ---------------------------------------------------------------------------

@contextmanager
def connect_to_database():
    """
    Open the scan-history database and return rows by column name.

    Use it as `with connect_to_database() as connection:`. The changes are
    committed on success, rolled back on error, and the connection is always
    closed afterwards.
    """
    connection = sqlite3.connect(DATABASE_FILE, timeout=10)
    connection.row_factory = sqlite3.Row
    try:
        yield connection
        connection.commit()
    except Exception:
        connection.rollback()
        raise
    finally:
        connection.close()


def create_database_if_needed():
    """Create the scan-history table the first time the app runs."""
    with connect_to_database() as connection:
        connection.execute(
            """
            CREATE TABLE IF NOT EXISTS scans (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                created_at TEXT NOT NULL,
                scan_type TEXT NOT NULL,
                input_text TEXT NOT NULL,
                verdict TEXT NOT NULL,
                risk_score INTEGER NOT NULL,
                explanation TEXT NOT NULL
            )
            """
        )


def save_scan(scan_type, submitted_text, verdict, risk_score, explanation):
    """Save a short summary of a scan so it appears in the dashboard history."""
    with connect_to_database() as connection:
        connection.execute(
            """
            INSERT INTO scans
                (created_at, scan_type, input_text, verdict, risk_score, explanation)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (
                datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                scan_type,
                submitted_text[:2000],
                verdict,
                int(risk_score),
                explanation[:3000],
            ),
        )


# ---------------------------------------------------------------------------
# Model and URL helpers
# ---------------------------------------------------------------------------

_model_cache = {}
_model_lock = threading.Lock()


def load_model_if_available(model_file):
    """
    Load a saved model once and reuse it, or return None if it is unusable.

    The app still works with basic warning signs when the model is missing,
    corrupted, or was saved by an incompatible scikit-learn version
    (fix that by running `python train_model.py` again).
    """
    key = str(model_file)
    with _model_lock:
        if key in _model_cache:
            return _model_cache[key]

        model = None
        if model_file.exists():
            try:
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore")
                    model = joblib.load(model_file)
            except Exception:  # noqa: BLE001 - any load failure means "no model"
                model = None

        _model_cache[key] = model
        return model


def get_url_features(url_text):
    """
    Turn a URL into the numeric features used by the Random Forest model,
    plus plain-English warning signs.

    The features come from url_features.py, the same code train_model.py uses.
    """
    url_text = (url_text or "").strip()
    features, details = extract_url_features(url_text)
    if features is None:
        return None, ["Please enter a valid URL or domain name."]

    has_ip_address = details["has_ip_address"]
    has_security_word = details["has_security_word"]
    has_unusual_ending = details["has_unusual_ending"]

    warning_signs = []

    if details["scheme"] != "https":
        warning_signs.append(
            "This URL does not use HTTPS. That alone does not mean it is malicious."
        )
    if has_ip_address:
        warning_signs.append(
            "The website address uses an IP address instead of a typical domain name."
        )
    if details["is_short_link"]:
        warning_signs.append(
            "This is a shortened link, so its final destination is not obvious."
        )
    if details["has_at_sign"]:
        warning_signs.append(
            "The URL contains '@', which can sometimes make the destination confusing."
        )
    if has_security_word:
        warning_signs.append(
            "The URL contains account or security-related words. Check the domain carefully."
        )
    if has_unusual_ending:
        warning_signs.append(
            "This domain ending can appear in suspicious links, but it is not proof of a scam."
        )
    if details["length"] > 100:
        warning_signs.append("The URL is unusually long.")

    if not warning_signs:
        warning_signs.append(
            "No obvious warning signs were found. This does not guarantee the site is safe."
        )

    return features, warning_signs


# ---------------------------------------------------------------------------
# Scan logic
# ---------------------------------------------------------------------------

def scan_url(url_text):
    """Check a URL using the trained model and a few explainable warning signs."""
    features, warning_signs = get_url_features(url_text)

    if features is None:
        return {"ok": False, "error": "Please enter a valid URL or domain."}

    url_model = load_model_if_available(URL_MODEL_FILE)
    model_score = None

    if url_model is not None:
        try:
            # The model uses 1 for the suspicious URL class.
            model_score = float(url_model.predict_proba([features])[0][1])
        except Exception:  # noqa: BLE001 - fall back to warning signs
            model_score = None

    # Give common warning signs points so users can understand the result.
    warning_points = 0
    warning_text = " ".join(warning_signs)

    if "does not use HTTPS" in warning_text:
        warning_points += 18
    if "IP address" in warning_text:
        warning_points += 25
    if "shortened link" in warning_text:
        warning_points += 20
    if "contains '@'" in warning_text:
        warning_points += 15
    if "account or security-related words" in warning_text:
        warning_points += 12
    if "domain ending" in warning_text:
        warning_points += 12
    if "unusually long" in warning_text:
        warning_points += 10

    warning_score = min(warning_points, 100)
    model_score_as_points = (
        round(model_score * 100) if model_score is not None else warning_score
    )

    # This blended score is a rough teaching aid, not a calibrated probability.
    risk_score = round(0.55 * model_score_as_points + 0.45 * warning_score)
    risk_score = max(0, min(100, risk_score))

    if risk_score >= 65:
        verdict = "High risk"
    elif risk_score >= 35:
        verdict = "Caution"
    else:
        verdict = "Lower risk"

    if model_score is None:
        warning_signs.append(
            "The URL model is unavailable, so this result uses basic warning signs only."
        )

    explanation = " ".join(warning_signs)
    save_scan("URL", url_text, verdict, risk_score, explanation)

    return {
        "ok": True,
        "type": "URL",
        "verdict": verdict,
        "risk_score": risk_score,
        "signals": warning_signs,
        "explanation": explanation,
        "model_note": (
            "This is an educational demo model. A low score does not prove a URL is safe."
        ),
    }


def scan_message(message_text):
    """Check a message or email for scam patterns and model predictions."""
    message_text = (message_text or "").strip()
    if not message_text:
        return {"ok": False, "error": "Please enter a message or email."}

    message_model = load_model_if_available(MESSAGE_MODEL_FILE)
    message_lower = message_text.lower()
    warning_signs = []

    for phrase in COMMON_SCAM_PHRASES:
        if phrase in message_lower:
            warning_signs.append(
                f'A possible scam phrase was found: "{phrase}".'
            )

    if re.search(r"\b(otp|one[- ]time password|cvv|pin|password)\b", message_lower):
        warning_signs.append(
            "The message mentions sensitive information. Never share OTPs, PINs or passwords."
        )

    if re.search(r"https?://|www\.", message_lower):
        warning_signs.append(
            "The message includes a web link. Check the destination independently."
        )

    if re.search(r"\b(prize|winner|lottery|reward|cashback|free money)\b", message_lower):
        warning_signs.append(
            "Unexpected prizes or rewards can be a warning sign."
        )

    if re.search(r"\b(pay|payment|transfer|fee|bank|kyc)\b", message_lower):
        warning_signs.append(
            "The message mentions money or banking. Confirm through an official channel."
        )

    scam_probability = None
    if message_model is not None:
        try:
            probabilities = message_model.predict_proba([message_text])[0]
            model_classes = list(message_model.classes_)
            if "scam" in model_classes:
                scam_probability = float(probabilities[model_classes.index("scam")])
            else:
                scam_probability = 0.0
        except Exception:  # noqa: BLE001 - fall back to warning signs
            scam_probability = None

    warning_probability = min(0.95, len(warning_signs) * 0.16)

    model_unavailable = scam_probability is None
    if model_unavailable:
        # Simple fallback if the trained model is missing or cannot be used.
        scam_probability = min(0.95, len(warning_signs) * 0.12)

    risk_score = round(
        100 * (0.75 * scam_probability + 0.25 * warning_probability)
    )
    risk_score = max(0, min(100, risk_score))

    if risk_score >= 65:
        verdict = "Likely scam"
    elif risk_score >= 35:
        verdict = "Needs caution"
    else:
        verdict = "Fewer warning signs"

    if not warning_signs:
        warning_signs.append(
            "No common scam indicators were found. Scams can still look convincing."
        )
    if model_unavailable:
        warning_signs.append(
            "The message model is unavailable, so this result relies on basic warning signs."
        )

    explanation = " ".join(warning_signs)
    save_scan("Message", message_text, verdict, risk_score, explanation)

    return {
        "ok": True,
        "type": "Message",
        "verdict": verdict,
        "risk_score": risk_score,
        "signals": warning_signs,
        "explanation": explanation,
        "model_note": (
            "This educational model was trained on example messages and can make mistakes."
        ),
    }


# ---------------------------------------------------------------------------
# Website pages and API routes
# ---------------------------------------------------------------------------

def get_scan_totals():
    """Return (total scans, high-risk scans) counted across the whole history."""
    with connect_to_database() as connection:
        total_scans = connection.execute(
            "SELECT COUNT(*) FROM scans"
        ).fetchone()[0]
        high_risk_scans = connection.execute(
            "SELECT COUNT(*) FROM scans WHERE risk_score >= 65"
        ).fetchone()[0]
    return total_scans, high_risk_scans


@app.errorhandler(413)
def request_too_large(_error):
    """Return JSON (not an HTML page) so the JavaScript can show a clear message."""
    return jsonify({"ok": False, "error": "The request is too large."}), 413


@app.route("/")
def home_page():
    """Show the dashboard and the most recent scans."""
    total_scans, high_risk_scans = get_scan_totals()

    with connect_to_database() as connection:
        recent_scans = connection.execute(
            "SELECT * FROM scans ORDER BY id DESC LIMIT 8"
        ).fetchall()

    return render_template(
        "index.html",
        total=total_scans,
        risky=high_risk_scans,
        recent=recent_scans,
    )


@app.route("/api/scan", methods=["POST"])
def scan_api():
    """Receive a scan request from JavaScript and return the analysis as JSON."""
    request_data = request.get_json(silent=True)
    if not isinstance(request_data, dict):
        return jsonify({"ok": False, "error": "Please send a JSON object."}), 400

    scan_type = request_data.get("type", "message")
    submitted_text = request_data.get("text", "")
    if not isinstance(submitted_text, str):
        return jsonify({"ok": False, "error": "The text must be a string."}), 400
    submitted_text = submitted_text.strip()

    if len(submitted_text) > 2000:
        return jsonify({
            "ok": False,
            "error": "Please keep the input under 2,000 characters.",
        }), 400

    if scan_type == "url":
        result = scan_url(submitted_text)
    elif scan_type == "message":
        result = scan_message(submitted_text)
    else:
        return jsonify({"ok": False, "error": "Unknown scan type."}), 400

    status_code = 200 if result.get("ok") else 400
    return jsonify(result), status_code


@app.route("/api/history")
def history_api():
    """Return the latest scan records for the dashboard."""
    with connect_to_database() as connection:
        scan_rows = connection.execute(
            "SELECT * FROM scans ORDER BY id DESC LIMIT 100"
        ).fetchall()

    return jsonify([dict(row) for row in scan_rows])


@app.route("/api/stats")
def stats_api():
    """Return dashboard counters computed over the whole scan history."""
    total_scans, high_risk_scans = get_scan_totals()
    return jsonify({"total": total_scans, "risky": high_risk_scans})


@app.route("/api/history/clear", methods=["POST"])
def clear_history_api():
    """Remove all saved scan records after the user confirms in the dashboard."""
    with connect_to_database() as connection:
        connection.execute("DELETE FROM scans")

    return jsonify({"ok": True})


@app.route("/api/tips")
def tips_api():
    """Provide a short list of everyday cybersecurity tips."""
    safety_tips = [
        "Never share OTPs, PINs, passwords or CVV with anyone.",
        "Open your bank or service by typing its official address yourself.",
        "Do not trust urgency, threats or unexpected prizes as proof of legitimacy.",
        "Check the sender and domain for misspellings or lookalike names.",
        "Do not install apps or remote-access tools at the request of an unknown caller.",
        "For money-related requests, verify using a trusted official number or app.",
    ]
    return jsonify(safety_tips)


# Create the database table when the app starts.
create_database_if_needed()


if __name__ == "__main__":
    # This server is intended for local development on your own computer.
    app.run(host="127.0.0.1", port=5000, debug=False)
