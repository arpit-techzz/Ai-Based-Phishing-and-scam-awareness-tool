"use strict";

const form = document.querySelector("#analyze-form");
const modeField = document.querySelector("#mode");
const textField = document.querySelector("#text");
const errorBox = document.querySelector("#form-error");
const submitButton = document.querySelector("#submit-button");
const results = document.querySelector("#results");

function node(tag, className, text) {
  const item = document.createElement(tag);
  if (className) item.className = className;
  if (text !== undefined) item.textContent = text;
  return item;
}

function renderDetails(list, items, empty) {
  list.replaceChildren();
  if (!items.length) {
    list.append(node("li", "empty", empty));
    return;
  }
  for (const item of items) {
    const li = node("li", "detail");
    const content = node("div");
    content.append(node("strong", "", item.label || item));
    if (item.detail) content.append(node("p", "", item.detail));
    li.append(node("span", "bullet", "•"), content);
    list.append(li);
  }
}

function showResult(data) {
  const score = Math.max(0, Math.min(100, Number(data.score) || 0));
  const badge = document.querySelector("#risk-badge");
  const ring = document.querySelector("#score-ring");
  document.querySelector("#score-value").textContent = String(score);
  document.querySelector("#result-label").textContent = data.label;
  document.querySelector("#result-summary").textContent = data.summary;
  document.querySelector("#method-note").textContent = data.method;
  badge.textContent = data.label;
  badge.className = `badge risk-${data.level}`;
  ring.className = `score-ring risk-${data.level}`;
  ring.style.setProperty("--score", `${score}%`);
  ring.setAttribute("role", "img");
  ring.setAttribute("aria-label", `Risk indicator score: ${score} out of 100`);
  renderDetails(document.querySelector("#flag-list"), data.flags || [],
    "No common warning signs matched. This does not guarantee safety.");
  renderDetails(document.querySelector("#recommendation-list"), data.recommendations || [],
    "Verify unexpected messages independently before acting.");

  const urlBox = document.querySelector("#checked-urls");
  const urlList = document.querySelector("#url-list");
  urlList.replaceChildren();
  urlBox.hidden = !(data.urls || []).length;
  for (const item of data.urls || []) {
    const li = node("li", "url-item");
    const info = node("div", "url-info");
    info.append(node("strong", "", item.host || "Unparsed link"));
    info.append(node("span", "", item.url));
    li.append(info, node("span", "url-score", `${item.score}/100 indicators`));
    urlList.append(li);
  }
  results.hidden = false;
  results.scrollIntoView({ behavior: "smooth", block: "start" });
}

modeField.addEventListener("change", () => {
  textField.placeholder = modeField.value === "url"
    ? "Paste one URL, for example https://example.com"
    : "Paste a message or email here. You can include a suspicious link.";
});
textField.addEventListener("input", () => {
  document.querySelector("#char-count").textContent =
    `${textField.value.length.toLocaleString()} / 10,000`;
});

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  errorBox.hidden = true;
  errorBox.textContent = "";
  const text = textField.value.trim();
  if (!text) {
    errorBox.textContent = "Enter a message or URL to check.";
    errorBox.hidden = false;
    textField.focus();
    return;
  }
  submitButton.disabled = true;
  submitButton.firstElementChild.textContent = "Checking for common signs…";
  try {
    const response = await fetch("/api/analyze", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ mode: modeField.value, text }),
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "The check could not be completed.");
    showResult(data);
  } catch (error) {
    errorBox.textContent = error.message || "Could not reach the local app. Try again.";
    errorBox.hidden = false;
  } finally {
    submitButton.disabled = false;
    submitButton.firstElementChild.textContent = "Check for warning signs";
  }
});
