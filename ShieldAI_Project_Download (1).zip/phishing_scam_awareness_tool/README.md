# ShieldAI — Phishing and Scam Awareness Tool

ShieldAI is a student project built with Python, Flask, HTML, CSS and JavaScript.
It checks suspicious URLs and messages, explains common warning signs, and keeps
a local history of scans.

## What is included?
- URL analysis with a Random Forest model and easy-to-understand warning signs.
- SMS/email analysis with TF-IDF and Logistic Regression.
- Dashboard counters and local SQLite scan history.
- Safety tips for everyday cybersecurity.
- A small sample dataset to demonstrate model training.

## Run in Jupyter Notebook
1. Extract the project ZIP.
2. Open Jupyter Notebook in the extracted project folder.
3. Open `ShieldAI_Jupyter_Notebook.ipynb`.
4. Run each cell from top to bottom.
5. Open `http://127.0.0.1:5000` after the Flask server starts.

## Run from a terminal
```bash
pip install -r requirements.txt
python train_model.py
python app.py
```
Then visit `http://127.0.0.1:5000`.

## How the models work
- The message model turns words and short phrases into numerical features using
  TF-IDF, then uses Logistic Regression to learn the sample labels.
- The URL model extracts simple details such as URL length, HTTPS usage and
  domain patterns, then uses a Random Forest classifier.
- The app combines model output with visible warning signs to explain its result.

## Important limitation
The included dataset is small and intended for learning. The model can be wrong,
and a low risk score does not mean a website or message is safe. Do not enter real
passwords, OTPs, private emails or other sensitive information. The app does not
open submitted URLs, and it stores scan text locally in `scan_history.db`.
Run the development server on your own computer only.
